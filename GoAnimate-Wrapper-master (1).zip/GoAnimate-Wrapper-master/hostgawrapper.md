# Host On Evennode
1. make a account
2. make a node.js evennode
3. open command prompt on your main pc (NOT EVENNODE) and run this command ``ssh-keygen -t rsa -C "your_email@example.com"``
4. go on the folder you saved it in and open the .PUB file
5. Copy everything inside the file
6. go on evennode, click account settings and paste the file on the public keys for git box and click save.
7. go back to your evennode app and go on the info tab
8. copy the Repository in Git deployment tab.
9. open cmd again and do cd desktop then git clone PASTEREPOHERE
10. get your lvm clone and copy all the files and paste it in the repo folder on your desktop with random letters.
11. go on cmd AGAIN and cd to the folder directory
12. download github desktop at https://desktop.github.com/
13. commit the changes and publish branch

# Host on VPS/ Own pc
if you want to host it on your own pc then simply clone or download this repo.
Then open cmd then cd to the folder 
then do npm install the npm start
